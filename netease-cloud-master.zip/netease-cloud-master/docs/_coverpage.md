<!-- _coverpage.md -->

 # 网易云升级全家桶

一个用于网易云音乐快速满级的服务。

- 每天自动升级
- 任务进度推送到微信
- 自定义网易云日推风格

[GitHub](https://github.com/ZainCheung/netease-cloud/) [Get Started](#首页)